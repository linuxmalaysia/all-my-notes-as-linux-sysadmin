---
name: noss-linguistic-auditor
description: >
  Audits NOSS Level 3 Competency Profile (CP) content for correct wording and
  sentence structure. Checks that Work Steps use Active Voice, Performance
  Criteria use Passive Voice, Steps and Criteria match 1-to-1, OS platform
  boundaries are not crossed, and no vague or overly complex language is used.
  Use this skill whenever an AI agent needs to review, correct, or validate the
  linguistic quality of CU content before publishing. No scripts required —
  all checks are performed by the agent reading these rules and examples.
---

# NOSS Linguistic Auditor Skill

## 1. Purpose

This skill teaches an AI agent to **read and audit** NOSS Level 3 Competency
Profile content for linguistic compliance.

The agent applies **four quality gates** by reading the content and comparing
it against the rules and examples in this document:

| Gate | Name | What it checks |
| :--- | :--- | :------------- |
| G1 | **Active Voice** | Work Steps begin with an action verb |
| G2 | **Passive Voice** | Performance Criteria contain a passive-voice indicator |
| G3 | **1-to-1 Mapping** | Step count exactly equals Criteria count per WA |
| G4 | **Language Cleanliness** | No vague phrases, no forbidden OS commands |

---

## 2. The Four Quality Gates

---

### Gate G1 — Active Voice (Work Steps)

**Rule:** Every Work Step must begin with a present-tense **action verb**.

A step describes what **the person does**. It must not begin with:
- A past-tense verb ending in `-ed` (e.g. `Installed`, `Configured`, `Verified`)
- A noun (e.g. `The system`, `Server`, `Network`)
- A passive construction (e.g. `Is installed`, `Was configured`)

#### ✅ PASS Examples (Active Voice)

```
Install the server operating system using the bootable USB drive.
Configure the hostname and static IP address in the network settings file.
Verify the network adapter link status using the ping command.
Open the firewall management console on the local system.
Check the system log directory for critical error entries.
```

#### ❌ FAIL Examples (Passive Voice in Steps)

```
Installed the server OS using the bootable USB.       ← past-tense, sounds passive
The hostname was configured in the settings file.     ← "was configured" = passive
Network adapter is verified using ping.               ← "is verified" = passive
System log directory is opened to check errors.       ← "is opened" = passive
```

#### 🔧 How to Fix

| ❌ FAIL | ✅ PASS |
| :------ | :------ |
| `Installed the server OS` | `Install the server OS` |
| `The hostname was configured` | `Configure the hostname` |
| `Network adapter is verified` | `Verify the network adapter` |

**Pattern:** Strip past tense / passive wrapper → start with bare infinitive verb.

---

### Gate G2 — Passive Voice (Performance Criteria)

**Rule:** Every Performance Criterion must contain a **passive-voice indicator**
verb and end with `in accordance with [reference/standard/policy]`.

A criterion describes what **was achieved**. It must:
1. Start with the **object** (not the person)
2. Contain a past-participle passive verb (see whitelist below)
3. End with `in accordance with [document/policy/procedure]`

#### Approved Passive Verb Whitelist

The criterion must contain **at least one** of these words:

```
accessed        activated       added           addressed       allocated
analysed        analyzed        applied         archived        assembled
assigned        audited         booted          captured        categorized
checked         cleared         cloned          closed          collected
compiled        completed       confirmed       configured      connected
conducted       converted       copied          created         defined
deployed        determined      diagnosed       disabled        displayed
documented      established     evaluated       executed        exported
extracted       filtered        formatted       generated       handled
identified      implemented     installed       inspected       investigated
isolated        launched        loaded          locked          logged
maintained      managed         mapped          matched         monitored
mounted         notified        operated        parsed          performed
prepared        provided        pulled          purged          queried
recorded        reclaimed       registered      removed         resolved
restored        restricted      retrieved       reviewed        reverted
saved           scheduled       secured         selected        set
simulated       started         stopped         structured      submitted
supported       synchronized    tested          toggled         traced
tracked         triaged         triggered       updated         uploaded
validated       verified        visualised      written
```

#### ✅ PASS Examples (Passive Voice Criteria)

```
Server operating system installed and license credentials configured in
accordance with license compliance guides.

Network adapter link status and gateway connectivity verified using ping
tools in accordance with connection guidelines.

System log directory accessed and critical error files identified in
accordance with diagnostic checklist.

Firewall inbound rules configured to block unauthorized packets in
accordance with host network defense policies.
```

#### ❌ FAIL Examples (Active / No Passive Indicator)

```
The technician installs the OS and sets up the credentials.
← Active voice, starts with "the technician"

User opens the firewall console and blocks the ports.
← Active voice, no passive verb from whitelist

Network settings should be correct for the system to work.
← Vague, no passive indicator, no "in accordance with"

Check that the ping works.
← Active command, not a criterion
```

#### 🔧 How to Fix

| ❌ FAIL | ✅ PASS |
| :------ | :------ |
| `The technician installs the OS` | `OS installed and credentials configured in accordance with license compliance guides.` |
| `User opens the firewall` | `Firewall configuration interface accessed in accordance with security policy.` |
| `Check that the ping works` | `Network connectivity verified using ping tools in accordance with connection guidelines.` |

**Pattern:** Object first → passive verb → `in accordance with [reference]`.

---

### Gate G3 — 1-to-1 Mapping

**Rule:** The number of Work Steps in a WA must **exactly equal** the number
of Performance Criteria in that same WA.

Each step N.M must have a matching criterion N.M.

#### ✅ PASS Example (5 steps = 5 criteria)

```
WORK STEPS                                    PERFORMANCE CRITERIA
1.1 Identify server installation specs.       1.1 Server specs identified in accordance with checklist.
1.2 Identify server hardware requirements.    1.2 Hardware requirements identified in accordance with procedure.
1.3 Identify server software requirements.    1.3 Software requirements identified in accordance with specs.
1.4 Map server network configuration.         1.4 Network config mapped in accordance with addressing scheme.
1.5 Prepare installation tools.               1.5 Tools prepared in accordance with handling guidelines.
```

#### ❌ FAIL Example (5 steps ≠ 4 criteria)

```
WORK STEPS                                    PERFORMANCE CRITERIA
1.1 Identify server installation specs.       1.1 Server specs identified in accordance with checklist.
1.2 Identify server hardware requirements.    1.2 Hardware requirements identified in accordance with procedure.
1.3 Identify server software requirements.    1.3 Software requirements identified in accordance with specs.
1.4 Map server network configuration.         1.4 Network config mapped in accordance with addressing scheme.
1.5 Prepare installation tools.               ← MISSING criterion 1.5
```

**Fix:** Add the missing criterion, or remove the extra step. Always balance.

---

### Gate G4 — Language Cleanliness

This gate has **three sub-checks**:

#### G4a — No Vague or "Guess and Check" Language

These phrases are **forbidden** anywhere in Work Steps or Performance Criteria:

| Forbidden Phrase | Why forbidden |
| :--------------- | :------------ |
| `guess` | No guessing in a structured operation |
| `trial and error` | Trainees need deterministic steps |
| `play around` | Unprofessional and unstructured |
| `try running` | Implies uncertainty — use `Run` instead |
| `check the screen error` | Too vague — specify what to check |
| `should work` | Not a verifiable outcome |
| `might be` | Ambiguous |
| `somehow` | Vague |

#### ✅ PASS (Precise language)

```
Run the system disk cleanup utility using the built-in tool.
Verify the backup status in the task scheduler log.
Identify the error code from the system event viewer.
```

#### ❌ FAIL (Vague language)

```
Try running the cleanup tool and see if it works.
Play around with the settings until the backup works.
Somehow get the error message from somewhere in the log.
```

---

#### G4b — No Forbidden OS Commands (OS Boundary Check)

Linux content must not reference Windows commands.
Windows content must not reference Linux commands.

**Forbidden in Linux content:**

```
ipconfig       powershell      cmd.exe
cls            dir /           dir \
```

**Forbidden in Windows content:**

```
apt update     apt install     clamscan
lynis          systemctl restart    sudo systemctl
```

#### ✅ PASS

```
[Linux step]  Check network interface settings using the ip addr command.
[Windows step] Check network adapter settings using the ipconfig command.
```

#### ❌ FAIL

```
[Linux step]  Use ipconfig to check network settings.     ← Windows command in Linux content
[Windows step] Run apt install to install the package.    ← Linux command in Windows content
```

---

#### G4c — No Overly Complex Commands in Trainee Steps

Commands in Work Steps must be simple, single-purpose, and Level 3 appropriate.

**Forbidden patterns:**

| Pattern | Why forbidden |
| :------ | :------------ |
| `awk` pipelines | Too complex for L3 trainees |
| `sed` inline substitution | Abstracted to `/scripts/` |
| `grep -E` or `grep -P` | Regex too advanced |
| More than 1 pipe `\|` in one command | Complex pipeline — abstract it |
| `perl -e` | Not a basic utility |

#### ✅ PASS (Simple commands)

```
cat /var/log/syslog
systemctl status nginx
ip addr show
ping -c 4 8.8.8.8
ls -lh /var/backups/
```

#### ❌ FAIL (Too complex for Level 3)

```
awk '{print $1}' /var/log/auth.log | sort | uniq -c | sort -rn | head -10
grep -E "Failed|Invalid" /var/log/auth.log | awk '{print $NF}' | sort
sed -i 's/^PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
```

**Fix:** Move complex commands to `/scripts/` bash files. Reference the script name in the step:
```
Run the audit-ssh-failures.sh script to extract failed login events.
```

---

## 3. How to Apply This Skill (Step-by-Step)

### Step 1 — Read the content

Read the Work Activity content to be audited. Identify:
- The WA title and code
- All Work Steps (numbered N.M)
- All Performance Criteria (numbered N.M)

### Step 2 — Run Gate G3 first (count check)

Count the steps and count the criteria.
If they do not match → flag immediately and stop. Fix the count before checking voice.

### Step 3 — Run Gate G1 (Active Voice on Steps)

For each step:
- Read the first word
- Is it a present-tense action verb? → PASS
- Does it end in `-ed`? → FAIL
- Does it start with `The`, `A`, `An`? → FAIL
- Does it contain `is/was/were + verb`? → FAIL

### Step 4 — Run Gate G2 (Passive Voice on Criteria)

For each criterion:
- Does it contain at least one word from the Passive Verb Whitelist? → PASS
- Does it end with `in accordance with [something]`? → Required
- Does it start with an object (not "The technician" or "The person")? → Required

### Step 5 — Run Gate G4 (Language Cleanliness)

Scan every line for:
- Forbidden vague phrases (G4a)
- Wrong OS commands for the platform (G4b)
- Complex multi-pipe commands or awk/sed (G4c)

### Step 6 — Report findings

For each error found, report in this format:

```
[GATE] [WA Code] [Step/Criterion Number]
Issue: [description of the problem]
Current text: "[the failing text]"
Suggested fix: "[the corrected text]"
```

### Step 7 — Confirm PASS

If no errors are found across all 4 gates:
```
✅ PASS — [WA Code]: All linguistic quality gates satisfied.
Steps: N | Criteria: N | Active Voice: ✓ | Passive Voice: ✓ | Language: ✓
```

---

## 4. Quick Reference Card

```
┌─────────────────────────────────────────────────────────────────┐
│               NOSS L3 LINGUISTIC QUALITY GATES                  │
├──────┬──────────────────────────────────────────────────────────┤
│  G1  │ WORK STEPS → Active Voice                                │
│      │ ✓ Start with action verb: Install / Configure / Verify   │
│      │ ✗ No past tense: Installed / Configured / Was verified   │
├──────┼──────────────────────────────────────────────────────────┤
│  G2  │ PERFORMANCE CRITERIA → Passive Voice                     │
│      │ ✓ Object first + passive verb + "in accordance with"     │
│      │ ✗ No active construction, no missing reference           │
├──────┼──────────────────────────────────────────────────────────┤
│  G3  │ 1-to-1 MAPPING                                           │
│      │ ✓ Step count = Criteria count (exact match)              │
│      │ ✗ Any mismatch = immediate FAIL                          │
├──────┼──────────────────────────────────────────────────────────┤
│  G4  │ LANGUAGE CLEANLINESS                                     │
│      │ ✓ Precise, deterministic language                        │
│      │ ✗ No: "try", "guess", "play around", "should work"       │
│      │ ✗ No: wrong OS commands for the platform                 │
│      │ ✗ No: awk / sed / grep -E / multi-pipe commands          │
└──────┴──────────────────────────────────────────────────────────┘
```

---

## 5. Scope Boundary

> **⚠️ LEVEL 3 CONSTRAINT**
>
> This skill audits content intended for **SPM-entry vocational trainees**.
> All corrections must maintain Level 3 simplicity.
> Do not introduce advanced terminology, complex commands, or Level 4+ concepts
> when suggesting fixes.

---

## 6. Related Skills

- **`noss-cp-docx-formatter`** — use after linguistic audit to regenerate CP documents
- **`noss-cpc-docx-formatter`** — use after audit to regenerate CPC documents
- **`template-noss-l3-skill`** — reference template for correct SKILL.md structure
